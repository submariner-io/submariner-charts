{{- define "broker-role" -}}
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: {{ template "submariner-k8s-broker.fullname" . }}-cluster
rules:
  - apiGroups:
      - submariner.io
    resources:
      - clusters
      - endpoints
    verbs:
      - create
      - get
      - list
      - watch
      - patch
      - update
      - delete
  - apiGroups:
      - submariner.io
    resources:
      - brokers
    verbs:
      - get
      - list
  - apiGroups:
      - multicluster.x-k8s.io
    resources:
      - serviceimports
      - serviceimports/status
    verbs:
      - create
      - get
      - list
      - watch
      - patch
      - update
      - delete
  - apiGroups:
      - discovery.k8s.io
    resources:
      - endpointslices
      - endpointslices/restricted
    verbs:
      - create
      - get
      - list
      - watch
      - patch
      - update
      - delete
  - apiGroups:
      - ""
    resources:
      - secrets
    verbs:
      - get
      - list
      - watch
  - apiGroups:
      - ""
    resources:
      - serviceaccounts
    verbs:
      - get
      - list
{{- end -}}
